// Runs in MAIN world — reads localStorage token and posts back to content script
// Supports both JSON-wrapped tokens (DeepSeek) and raw string tokens (Kimi)
(function() {
  window.addEventListener('message', function(e) {
    if (e.source !== window) return;
    if (e.data && e.data.type === 'punkgo:readToken') {
      try {
        var raw = localStorage.getItem(e.data.key || 'userToken');
        if (!raw) {
          window.postMessage({ type: 'punkgo:tokenResult', token: null }, location.origin);
          return;
        }
        // Try JSON parse first (DeepSeek stores { value: "..." })
        // Fall back to raw string (Kimi stores bare JWT)
        var token = null;
        try {
          var parsed = JSON.parse(raw);
          token = parsed && parsed.value ? parsed.value : raw;
        } catch(jsonErr) {
          token = raw;
        }
        window.postMessage({ type: 'punkgo:tokenResult', token: token }, location.origin);
      } catch(err) {
        window.postMessage({ type: 'punkgo:tokenResult', token: null }, location.origin);
      }
    }
  });
})();
